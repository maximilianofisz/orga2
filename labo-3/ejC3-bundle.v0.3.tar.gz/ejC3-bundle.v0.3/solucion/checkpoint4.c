#include "checkpoints.h"

/* Pueden programar alguna rutina auxiliar del checkpoint 4 acá */

